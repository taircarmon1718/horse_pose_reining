# Horses > 2024-06-11 3:49pm
https://universe.roboflow.com/saumort/horses-upigv

Provided by a Roboflow user
License: CC BY 4.0

